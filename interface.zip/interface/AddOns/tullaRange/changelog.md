# tullaRange release notes

## 8.2.2

* Added classic build

## 8.2.1

* Automated releases

## 8.2.0

* Updated TOC for 8.2.0
* Verified the addon works with classic
* Cleaned up code a tiny bit
