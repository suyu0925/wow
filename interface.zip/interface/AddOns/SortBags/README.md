# SortBags
Bag sorting for 1.12 and 1.13.<br/>
__IMPORTANT: Use this branch for classic: https://github.com/shirsig/SortBags/tree/retail__<br/>
__IMPORTANT: The folder name must be "SortBags"__<br/>
__IMPORTANT: If you want buttons then get this too: https://github.com/shirsig/Cleanup__

```
/run SortBags() -- Sort bags
/run SortBankBags() -- Sort bank
/run SetSortBagsRightToLeft(Boolean) -- Set sort direction
/run GetSortBagsRightToLeft(): Boolean -- Get sort direction
```
