local CTM, C, L, _ = unpack(select(2, ...))
if CTM.locale ~= "deDE" then return end

-----------------------------
--	deDE client
-----------------------------
-- main frame
L.gui_threat		= "Bedrohung"

-- config frame
L.default			= "Standard"
