local CTM, C, L, _ = unpack(select(2, ...))
if CTM.locale ~= "itIT" then return end

-----------------------------
--	itIT client
-----------------------------
-- main frame
L.gui_threat		= "Minaccia"

-- config frame
L.default			= "Predefinito"
