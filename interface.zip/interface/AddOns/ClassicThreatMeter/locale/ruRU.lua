local CTM, C, L, _ = unpack(select(2, ...))
if CTM.locale ~= "ruRU" then return end

-----------------------------
--	ruRU client
-----------------------------
-- main frame
L.gui_threat		= "Угроза"

-- config frame
L.default			= "По умолчанию"
