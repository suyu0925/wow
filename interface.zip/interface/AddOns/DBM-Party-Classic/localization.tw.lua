if GetLocale() ~= "zhTW" then return end
local L

-------------------------
--  Blackfathom Deeps  --
-----------------------------
--  Ghamoo'Ra  --
-----------------------------
L = DBM:GetModLocalization(368)
