local mod	= DBM:NewMod("BruegalIronknuckle", "DBM-Party-Classic", 15)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20190728014419")
mod:SetCreatureID(1720)

mod:RegisterCombat("combat")
