local mod	= DBM:NewMod(450, "DBM-Party-Classic", 16, 236)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20190824201836")
mod:SetCreatureID(10516)
mod:SetEncounterID(472)

mod:RegisterCombat("combat")
