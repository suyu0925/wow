local mod	= DBM:NewMod("RazorclawtheButcher", "DBM-Party-Classic", 14)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20190728014419")
mod:SetCreatureID(3886)

mod:RegisterCombat("combat")
